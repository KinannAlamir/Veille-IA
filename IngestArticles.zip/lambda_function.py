﻿import json
import logging
import hashlib
import boto3
import urllib.request
import feedparser
from botocore.exceptions import ClientError

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Config
TABLE_NAME = "TechWatch_Articles"
RSS_FEEDS = [
    "https://aws.amazon.com/about-aws/whats-new/recent/feed/",
    "https://hnrss.org/frontpage"
]

dynamodb = boto3.resource("dynamodb", region_name="eu-west-1") # Changez la région DynamoDB si besoin
bedrock = boto3.client("bedrock-runtime", region_name="eu-west-3") # Paris pour Mistral 7B

def scrape_articles(limit_per_feed=2):
    """Scrapes recent articles from RSS feeds."""
    articles = []
    
    for feed_url in RSS_FEEDS:
        logger.info(f"Scraping {feed_url}")
        try:
            # feedparser gère les requêtes HTTP, mais on peut personnaliser si besoin
            feed = feedparser.parse(feed_url)
            
            for entry in feed.entries[:limit_per_feed]:
                content = getattr(entry, "content", [{"value": ""}])[0]["value"] if hasattr(entry, "content") else getattr(entry, "summary", "")
                    
                article = {
                    "id": entry.link,
                    "title": getattr(entry, "title", "Sans titre"),
                    "url": entry.link,
                    "date": getattr(entry, "published", "Date inconnue"),
                    "content": content
                }
                articles.append(article)
        except Exception as e:
            logger.error(f"Error scraping {feed_url}: {e}")
            
    return articles

def article_exists(article_id):
    """Checks if an article exists in DynamoDB."""
    table = dynamodb.Table(TABLE_NAME)
    try:
        response = table.get_item(Key={"PK": "article", "SK": article_id})
        return "Item" in response
    except ClientError as e:
        logger.error(f"DB Check Error: {e}")
        return False

def call_bedrock(content, title):
    """Calls Mistral 7B on Bedrock."""
    model_id = "mistral.mistral-7b-instruct-v0:2"
    prompt = f"""Tu es un analyste technologique expert Wavestone. Analyse le texte suivant et renvoie la réponse EXACTEMENT au format JSON spécifié, sans aucun texte avant ou après.

Format JSON attendu:
{{
  "tag": "Un mot clé (ex: IA, CLOUD, CYBER)",
  "topicId": "Un identifiant parmi: automation, cloud, ia, boosting_cto",
  "highLevel": {{
    "linkedinHook": "Une accroche LinkedIn avec emojis, stratégique.",
    "facts": ["Fait 1", "Fait 2"],
    "summary": "Résumé de l'impact métier."
  }},
  "lowLevel": {{
    "linkedinHook": "Accroche LinkedIn technique.",
    "facts": ["Fait technique 1", "Fait technique 2"],
    "summary": "Résumé de stack."
  }}
}}

TEXTE À ANALYSER (Titre: {title}):
{content[:2000]}
"""
    
    mistral_prompt = f"<s>[INST] {prompt} [/INST]"
    request_body = {
        "prompt": mistral_prompt,
        "max_tokens": 1024,
        "temperature": 0.5
    }

    try:
        response = bedrock.invoke_model(modelId=model_id, body=json.dumps(request_body))
        response_body = json.loads(response.get('body').read())
        return json.loads(response_body.get("outputs")[0].get("text"))
    except Exception as e:
        logger.error(f"Bedrock Error: {e}")
        return None

def save_article(article):
    """Saves enriched article to DynamoDB."""
    table = dynamodb.Table(TABLE_NAME)
    item = {
        "PK": "article",
        "SK": article["id"],
        **article
    }
    try:
        table.put_item(
            Item=item,
            ConditionExpression="attribute_not_exists(PK) AND attribute_not_exists(SK)"
        )
        logger.info(f"Saved {article['id']}.")
    except ClientError as e:
         logger.warning(f"DynamoDB Error during save: {e}")

def lambda_handler(event, context):
    """Main Lambda entry point triggered by EventBridge."""
    logger.info("Starting automated ingestion schedule...")
    articles = scrape_articles()
    
    processed_count = 0
    skipped_count = 0
    
    for idx, article in enumerate(articles):
        article_hash = hashlib.md5(article["url"].encode()).hexdigest()[:8]
        generated_id = f"news_auto_{article_hash}"
        
        if article_exists(generated_id):
            logger.info(f"Skipping existing: {generated_id}")
            skipped_count += 1
            continue
            
        enriched = call_bedrock(article["content"], article["title"])
        
        if enriched:
            final_doc = {
                "id": generated_id,
                "tag": enriched.get("tag", "TECH"),
                "topicId": enriched.get("topicId", "automation"),
                "title": article["title"],
                "source": "RSS Auto-Ingest",
                "date": article["date"],
                "score": str(80 + idx),
                "period": "Cette semaine",
                "comments": "0",
                "shares": "0",
                "highLevel": enriched.get("highLevel", {}),
                "lowLevel": enriched.get("lowLevel", {})
            }
            save_article(final_doc)
            processed_count += 1
            
    return {
        "statusCode": 200,
        "body": json.dumps(f"Ingestion complete: {processed_count} processed, {skipped_count} skipped.")
    }

